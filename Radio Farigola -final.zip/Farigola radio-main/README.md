# Ràdio Farigola

- URL de Netlify: 
- Vídeo (3 minuts com a màxim): 
- Sessió de classe: inici __:__ · final __:__

## Autoavaluació

| # | Requisit | Punts | Em dono | Evidència |
|---:|---|---:|---:|---|
| R1 | Estructura i navegació | 1 | | |
| R2 | Disposició | 1,25 | | |
| R3 | Inici | 0,75 | | |
| R4 | Programació | 1,75 | | |
| R5 | Novetats | 0,75 | | |
| R6 | Història | 1 | | |
| R7 | Participa | 1,25 | | |
| R8 | Estil amb regles | 0,75 | | |
| R9 | Validació, publicació i procés | 0,5 | | |
| R10 | Àudio | 0,5 | | |
| R11 | Maqueta | 0,5 | | |
| | **Total** | **10** | | |

## Tres errors

1. Què vaig escriure, què esperava, què va sortir, quina pàgina he de repassar:
2. 
3. 
